﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesafioRedeService
{
    public partial class Form1 : Form
    {
     
        private List<int> numeros = new List<int>();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        // Desafios 1 e 2
        private void numeroInformado_TextChanged(object sender, KeyPressEventArgs e)
        {
            // Permitir apenas números na caixa de texto
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Por favor, digite apenas números inteiros.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void adicionarNumero_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(numeroInformado.Text))
            {
                if (int.TryParse(numeroInformado.Text, out int novoNumero))
                {
                    // Adicionar o número à lista
                    numeros.Add(novoNumero);

                    // Exibir números ordenados no TextBox dentro do GroupBox
                    numerosCrescentes.Text = string.Join(Environment.NewLine, numeros.OrderBy(n => n));
                }
                else
                {
                    MessageBox.Show("Por favor, digite um número inteiro válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                numeroInformado.Text = string.Empty;
                // Adicione isto no final do método adicionarNumero_Click para depuração
                Console.WriteLine($"Conteúdo de numerosCrescentes:\n{numerosCrescentes.Text}");
            }
        }
        private void btnCriarArquivoNumeros_Click_1(object sender, EventArgs e)
        {
            
            try
            {
                // Verificar se há números para salvar
                if (numeros.Any())
                {
                    // Caminho do arquivo na pasta do projeto
                    string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "numeros_ordenar.txt");

                    // Criar o arquivo e obter o stream de escrita
                    using (StreamWriter writer = new StreamWriter(filePath))
                    {
                        // Escrever cada número no arquivo
                        foreach (var numero in numeros.OrderBy(n => n))
                        {
                            writer.WriteLine(numero.ToString());
                        }
                    }

                    MessageBox.Show($@"Arquivo 'numeros_ordenar.txt' criado com sucesso na mesma pasta do arquivo executável da aplicação.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Não há números para salvar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao criar o arquivo: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void btnAbrirArquivoNumeros_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Caminho do arquivo na pasta do projeto
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "numeros_ordenar.txt");

                // Verificar se o arquivo existe
                if (File.Exists(filePath))
                {
                    // Abrir o arquivo com o aplicativo padrão associado
                    Process.Start(filePath);
                }
                else
                {
                    MessageBox.Show("O arquivo 'numeros_ordenar.txt' não foi encontrado.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao abrir o arquivo: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /* Fim desafio 1 e 2*/



        /* Desafio 3,4 e 5 */
        private void btnCriarArquivoDataJson_Click(object sender, EventArgs e)
        {
            try
            {
                // Criar lista de 100 itens clsTeste
                List<clsTeste> listaTeste = new List<clsTeste>();
                for (int i = 1; i <= 100; i++)
                {
                    listaTeste.Add(new clsTeste
                    {
                        Codigo = i,
                        Descricao = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss.fff")
                    });
                }

                // Serializar a lista em formato JSON e gravar no arquivo data.json
                string json = JsonConvert.SerializeObject(listaTeste, Formatting.Indented);
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data.json");
                File.WriteAllText(filePath, json);

                MessageBox.Show($"Arquivo 'data.json' criado com sucesso na mesma pasta do arquivo executável da aplicação", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao criar o arquivo JSON: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCarregarGrid_Click(object sender, EventArgs e)
        {
            try
            {
                // Caminho do arquivo na pasta do projeto
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data.json");

                // Verificar se o arquivo existe
                if (File.Exists(filePath))
                {
                    // Ler o conteúdo do arquivo e desserializar para a lista de clsTeste
                    string json = File.ReadAllText(filePath);
                    List<clsTeste> listaTeste = JsonConvert.DeserializeObject<List<clsTeste>>(json);

                    // Exibir os dados no Grid
                    gridDataJson.DataSource = listaTeste;
                }
                else
                {
                    MessageBox.Show("O arquivo 'data.json' não foi encontrado.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar os dados do arquivo JSON: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void gridDataJson_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        /* Fim Desafio 3,4 e 5 */


        /* Desafio 6 */
        private void btnConsultar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtCEP.Text))
            {
                using (var ws = new WSCorreiros.AtendeClienteClient())
                {
                    try
                    {
                        var endereco = ws.consultaCEP(txtCEP.Text.Trim());

                        txtEstado.Text = endereco.uf;
                        txtCidade.Text = endereco.cidade;
                        txtBairro.Text = endereco.bairro;
                        txtRua.Text = endereco.end;
                        txtCepResultado.Text = endereco.cep;
                        txtComplemento2.Text = endereco.complemento2;

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }                }
            }
            else
            {
                MessageBox.Show("Informe um CEP válido!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCEP.Text = string.Empty;
            txtEstado.Text = string.Empty;
            txtCidade.Text = string.Empty;
            txtBairro.Text = string.Empty;
            txtRua.Text = string.Empty;
            txtComplemento2.Text = string.Empty;
            txtCepResultado.Text = string.Empty;

        }
        // Fim Desafio 6

        // Desafio 7
        private void exibirBancos_Click(object sender, EventArgs e)
        {

            var bancos = Banco.BuscarBancos();

            if (dataGridViewBancos.Columns.Count == 0)
            {
                dataGridViewBancos.Columns.Add("ISPB", "ISPB");
                dataGridViewBancos.Columns.Add("Name", "Name");
                dataGridViewBancos.Columns.Add("Code", "Code");
                dataGridViewBancos.Columns.Add("FullName", "FullName");
            }

            foreach (Banco b in bancos)
            {
                // Adicione as linhas aos valores das colunas correspondentes
                dataGridViewBancos.Rows.Add(b.ISPB, b.Name, b.Code, b.FullName);
            }
        }
        // Fim desafio 7

       

        // Desafio 8
        private void baixarImagemRedeService_Click_1(object sender, EventArgs e)
        {
            string imageUrl = "https://redeservice.com.br/wp-content/uploads/2020/07/redeservice-logo.png";

            byte[] imageData = DownloadImage(imageUrl);

            if (imageData != null)
            {
                // Converter os dados da imagem para base64
                string base64Image = Convert.ToBase64String(imageData);

                // Exibir a imagem na RichTextBox
                DisplayImageInRichTextBox(base64Image);

                SaveImageLocally(imageData, "redeservice-logo.png");
            }
            else
            {
                MessageBox.Show("Não foi possível baixar a imagem da URL especificada.");
            }
        }
        private byte[] DownloadImage(string imageUrl)
        {
            try
            {
                using (WebClient webClient = new WebClient())
                {
                    // Baixar os dados da imagem
                    return webClient.DownloadData(imageUrl);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao baixar a imagem: {ex.Message}");
                return null;
            }
        }
        private void DisplayImageInRichTextBox(string base64Image)
        {
            // Defina o texto da RichTextBox como a string base64 da imagem
            richTextBox1.Text = base64Image;
        }  
        private void SaveImageLocally(byte[] imageData, string localPath)
        {
            try
            {
                // Salvar os dados da imagem localmente
                File.WriteAllBytes(localPath, imageData);
                MessageBox.Show($"Imagem salva na mesma pasta do arquivo executável da aplicação, como: {localPath}", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao salvar a imagem localmente: {ex.Message}");
            }
        }
        /*Fim Desafio 8*/


    }
}

