﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace DesafioRedeService
{
    public class Banco
    {
        public string ISPB { get; set; }
        public string Name { get; set; }
        public int? Code { get; set; }
        public string FullName { get; set; }

        public static List<Banco> BuscarBancos() {
            string url = "https://brasilapi.com.br/api/banks/v1";



            string json = (new System.Net.WebClient()).DownloadString(url);

            var ban = JsonConvert.DeserializeObject<List<Banco>>(json);
            return ban;
        }

        
    }
}
