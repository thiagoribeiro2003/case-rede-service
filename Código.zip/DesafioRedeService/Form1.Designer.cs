﻿namespace DesafioRedeService
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnAbrirArquivoNumeros = new System.Windows.Forms.Button();
            this.btnCriarArquivoNumeros = new System.Windows.Forms.Button();
            this.numerosCrescentes = new System.Windows.Forms.RichTextBox();
            this.adicionarNumero = new System.Windows.Forms.Button();
            this.numeroInformado = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.gridDataJson = new System.Windows.Forms.DataGridView();
            this.btnCarregarGrid = new System.Windows.Forms.Button();
            this.btnCriarArquivoDataJson = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtEstado = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtUnidadesPostagem = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtCepResultado = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtComplemento2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtRua = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBairro = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCidade = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCEP = new System.Windows.Forms.MaskedTextBox();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dataGridViewBancos = new System.Windows.Forms.DataGridView();
            this.exibirBancos = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.baixarImagemRedeService = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDataJson)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBancos)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(397, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Desafio Rede Service (.NET)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(415, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Thiago Ribeiro Lopes da Silva";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(19, 109);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1383, 617);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage1.Controls.Add(this.btnAbrirArquivoNumeros);
            this.tabPage1.Controls.Add(this.btnCriarArquivoNumeros);
            this.tabPage1.Controls.Add(this.numerosCrescentes);
            this.tabPage1.Controls.Add(this.adicionarNumero);
            this.tabPage1.Controls.Add(this.numeroInformado);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Location = new System.Drawing.Point(4, 34);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1375, 579);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Q1 e Q2";
            // 
            // btnAbrirArquivoNumeros
            // 
            this.btnAbrirArquivoNumeros.Location = new System.Drawing.Point(889, 256);
            this.btnAbrirArquivoNumeros.Name = "btnAbrirArquivoNumeros";
            this.btnAbrirArquivoNumeros.Size = new System.Drawing.Size(148, 36);
            this.btnAbrirArquivoNumeros.TabIndex = 7;
            this.btnAbrirArquivoNumeros.Text = "Abrir Arquivo";
            this.btnAbrirArquivoNumeros.UseVisualStyleBackColor = true;
            this.btnAbrirArquivoNumeros.Click += new System.EventHandler(this.btnAbrirArquivoNumeros_Click_1);
            // 
            // btnCriarArquivoNumeros
            // 
            this.btnCriarArquivoNumeros.Location = new System.Drawing.Point(889, 214);
            this.btnCriarArquivoNumeros.Name = "btnCriarArquivoNumeros";
            this.btnCriarArquivoNumeros.Size = new System.Drawing.Size(148, 36);
            this.btnCriarArquivoNumeros.TabIndex = 6;
            this.btnCriarArquivoNumeros.Text = "Criar Arquivo";
            this.btnCriarArquivoNumeros.UseVisualStyleBackColor = true;
            this.btnCriarArquivoNumeros.Click += new System.EventHandler(this.btnCriarArquivoNumeros_Click_1);
            // 
            // numerosCrescentes
            // 
            this.numerosCrescentes.Location = new System.Drawing.Point(23, 214);
            this.numerosCrescentes.Name = "numerosCrescentes";
            this.numerosCrescentes.Size = new System.Drawing.Size(840, 359);
            this.numerosCrescentes.TabIndex = 5;
            this.numerosCrescentes.Text = "";
            // 
            // adicionarNumero
            // 
            this.adicionarNumero.BackColor = System.Drawing.Color.Chartreuse;
            this.adicionarNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adicionarNumero.Location = new System.Drawing.Point(381, 156);
            this.adicionarNumero.Name = "adicionarNumero";
            this.adicionarNumero.Size = new System.Drawing.Size(138, 36);
            this.adicionarNumero.TabIndex = 4;
            this.adicionarNumero.Text = "adicionar";
            this.adicionarNumero.UseVisualStyleBackColor = false;
            this.adicionarNumero.Click += new System.EventHandler(this.adicionarNumero_Click);
            // 
            // numeroInformado
            // 
            this.numeroInformado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numeroInformado.Location = new System.Drawing.Point(218, 156);
            this.numeroInformado.Name = "numeroInformado";
            this.numeroInformado.Size = new System.Drawing.Size(150, 30);
            this.numeroInformado.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(18, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(191, 25);
            this.label5.TabIndex = 2;
            this.label5.Text = "Informe um número: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(18, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(872, 50);
            this.label4.TabIndex = 1;
            this.label4.Text = "2. Agora grave os números visualizados cada 1 em uma linha em um arquivo texto na" +
    " pasta raiz da \r\naplicação de nome numeros_ordenar.txt.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(18, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(828, 50);
            this.label3.TabIndex = 0;
            this.label3.Text = "1. Faça a aplicação permitir a digitação de números e mostre esses números em tel" +
    "a de forma \r\nordenada. ";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.gridDataJson);
            this.tabPage2.Controls.Add(this.btnCarregarGrid);
            this.tabPage2.Controls.Add(this.btnCriarArquivoDataJson);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Location = new System.Drawing.Point(4, 34);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1375, 579);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Q3, Q4 e Q5";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // gridDataJson
            // 
            this.gridDataJson.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridDataJson.Location = new System.Drawing.Point(23, 266);
            this.gridDataJson.Name = "gridDataJson";
            this.gridDataJson.RowHeadersWidth = 51;
            this.gridDataJson.RowTemplate.Height = 24;
            this.gridDataJson.Size = new System.Drawing.Size(862, 307);
            this.gridDataJson.TabIndex = 5;
            this.gridDataJson.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridDataJson_CellContentClick);
            // 
            // btnCarregarGrid
            // 
            this.btnCarregarGrid.Location = new System.Drawing.Point(343, 204);
            this.btnCarregarGrid.Name = "btnCarregarGrid";
            this.btnCarregarGrid.Size = new System.Drawing.Size(300, 46);
            this.btnCarregarGrid.TabIndex = 4;
            this.btnCarregarGrid.Text = "Carregar Grid";
            this.btnCarregarGrid.UseVisualStyleBackColor = true;
            this.btnCarregarGrid.Click += new System.EventHandler(this.btnCarregarGrid_Click);
            // 
            // btnCriarArquivoDataJson
            // 
            this.btnCriarArquivoDataJson.Location = new System.Drawing.Point(23, 204);
            this.btnCriarArquivoDataJson.Name = "btnCriarArquivoDataJson";
            this.btnCriarArquivoDataJson.Size = new System.Drawing.Size(300, 46);
            this.btnCriarArquivoDataJson.TabIndex = 3;
            this.btnCriarArquivoDataJson.Text = "Criar arquivo data.json\r\n";
            this.btnCriarArquivoDataJson.UseVisualStyleBackColor = true;
            this.btnCriarArquivoDataJson.Click += new System.EventHandler(this.btnCriarArquivoDataJson_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(18, 165);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(791, 25);
            this.label14.TabIndex = 2;
            this.label14.Text = "5. Crie um Grid, leia o arquivo data.json que foi gravado, e mostre os dados no G" +
    "rid criado.";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(18, 127);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(764, 25);
            this.label13.TabIndex = 1;
            this.label13.Text = "4. Grave a lista do item 3, em um arquivo de nome data.json na pasta raiz da apli" +
    "cação.";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 14);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(867, 100);
            this.label12.TabIndex = 0;
            this.label12.Text = resources.GetString("label12.Text");
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnLimpar);
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Controls.Add(this.txtCEP);
            this.tabPage4.Controls.Add(this.btnConsultar);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Location = new System.Drawing.Point(4, 34);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1375, 579);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Q6";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.Red;
            this.btnLimpar.Location = new System.Drawing.Point(812, 83);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(105, 40);
            this.btnLimpar.TabIndex = 8;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtEstado);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtUnidadesPostagem);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txtCepResultado);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txtComplemento2);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtRua);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtBairro);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtCidade);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(21, 134);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(903, 439);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Resultado";
            // 
            // txtEstado
            // 
            this.txtEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEstado.Location = new System.Drawing.Point(11, 343);
            this.txtEstado.Name = "txtEstado";
            this.txtEstado.Size = new System.Drawing.Size(886, 27);
            this.txtEstado.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 315);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 20);
            this.label7.TabIndex = 14;
            this.label7.Text = "UF:";
            // 
            // txtUnidadesPostagem
            // 
            this.txtUnidadesPostagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUnidadesPostagem.Location = new System.Drawing.Point(11, 400);
            this.txtUnidadesPostagem.Name = "txtUnidadesPostagem";
            this.txtUnidadesPostagem.Size = new System.Drawing.Size(886, 27);
            this.txtUnidadesPostagem.TabIndex = 13;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(6, 377);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(164, 20);
            this.label18.TabIndex = 12;
            this.label18.Text = "Unidades Postagem:";
            // 
            // txtCepResultado
            // 
            this.txtCepResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCepResultado.Location = new System.Drawing.Point(11, 110);
            this.txtCepResultado.Name = "txtCepResultado";
            this.txtCepResultado.Size = new System.Drawing.Size(886, 27);
            this.txtCepResultado.TabIndex = 11;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 89);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 20);
            this.label17.TabIndex = 10;
            this.label17.Text = "CEP:";
            // 
            // txtComplemento2
            // 
            this.txtComplemento2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComplemento2.Location = new System.Drawing.Point(10, 225);
            this.txtComplemento2.Name = "txtComplemento2";
            this.txtComplemento2.Size = new System.Drawing.Size(886, 27);
            this.txtComplemento2.TabIndex = 9;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(5, 204);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(126, 20);
            this.label16.TabIndex = 8;
            this.label16.Text = "Complemento2:";
            // 
            // txtRua
            // 
            this.txtRua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRua.Location = new System.Drawing.Point(11, 283);
            this.txtRua.Name = "txtRua";
            this.txtRua.Size = new System.Drawing.Size(886, 27);
            this.txtRua.TabIndex = 7;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 262);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 20);
            this.label11.TabIndex = 6;
            this.label11.Text = "End:";
            // 
            // txtBairro
            // 
            this.txtBairro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBairro.Location = new System.Drawing.Point(11, 55);
            this.txtBairro.Name = "txtBairro";
            this.txtBairro.Size = new System.Drawing.Size(886, 27);
            this.txtBairro.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 20);
            this.label10.TabIndex = 4;
            this.label10.Text = "Bairro:";
            // 
            // txtCidade
            // 
            this.txtCidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCidade.Location = new System.Drawing.Point(11, 172);
            this.txtCidade.Name = "txtCidade";
            this.txtCidade.Size = new System.Drawing.Size(886, 27);
            this.txtCidade.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 20);
            this.label8.TabIndex = 2;
            this.label8.Text = "Cidade:";
            // 
            // txtCEP
            // 
            this.txtCEP.BackColor = System.Drawing.SystemColors.Info;
            this.txtCEP.Location = new System.Drawing.Point(188, 88);
            this.txtCEP.Name = "txtCEP";
            this.txtCEP.Size = new System.Drawing.Size(117, 30);
            this.txtCEP.TabIndex = 6;
            // 
            // btnConsultar
            // 
            this.btnConsultar.BackColor = System.Drawing.Color.LightGray;
            this.btnConsultar.Location = new System.Drawing.Point(324, 83);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(110, 40);
            this.btnConsultar.TabIndex = 5;
            this.btnConsultar.Text = "Buscar";
            this.btnConsultar.UseVisualStyleBackColor = false;
            this.btnConsultar.Click += new System.EventHandler(this.btnConsultar_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(15, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(159, 25);
            this.label9.TabIndex = 3;
            this.label9.Text = "Informe o CEP:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(908, 50);
            this.label6.TabIndex = 0;
            this.label6.Text = "6. Consuma o webservice dos correios passando um CEP qualquer e mostre em tela o " +
    "endereço que o \r\nmesmo retornar.";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dataGridViewBancos);
            this.tabPage5.Controls.Add(this.exibirBancos);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Location = new System.Drawing.Point(4, 34);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1375, 579);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Q7";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dataGridViewBancos
            // 
            this.dataGridViewBancos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBancos.Location = new System.Drawing.Point(11, 133);
            this.dataGridViewBancos.Name = "dataGridViewBancos";
            this.dataGridViewBancos.RowHeadersWidth = 51;
            this.dataGridViewBancos.RowTemplate.Height = 24;
            this.dataGridViewBancos.Size = new System.Drawing.Size(739, 440);
            this.dataGridViewBancos.TabIndex = 2;
            // 
            // exibirBancos
            // 
            this.exibirBancos.Location = new System.Drawing.Point(11, 64);
            this.exibirBancos.Name = "exibirBancos";
            this.exibirBancos.Size = new System.Drawing.Size(273, 36);
            this.exibirBancos.TabIndex = 1;
            this.exibirBancos.Text = "Consultar e Mostrar";
            this.exibirBancos.UseVisualStyleBackColor = true;
            this.exibirBancos.Click += new System.EventHandler(this.exibirBancos_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 19);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(523, 25);
            this.label15.TabIndex = 0;
            this.label15.Text = "7. Consuma a API para buscar a lista de bancos brasileiros";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.richTextBox1);
            this.tabPage3.Controls.Add(this.baixarImagemRedeService);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Location = new System.Drawing.Point(4, 34);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1375, 579);
            this.tabPage3.TabIndex = 5;
            this.tabPage3.Text = "Q8";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(11, 141);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(638, 432);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // baixarImagemRedeService
            // 
            this.baixarImagemRedeService.Location = new System.Drawing.Point(11, 84);
            this.baixarImagemRedeService.Name = "baixarImagemRedeService";
            this.baixarImagemRedeService.Size = new System.Drawing.Size(312, 35);
            this.baixarImagemRedeService.TabIndex = 1;
            this.baixarImagemRedeService.Text = "Baixar Imagem e Gravar";
            this.baixarImagemRedeService.UseVisualStyleBackColor = true;
            this.baixarImagemRedeService.Click += new System.EventHandler(this.baixarImagemRedeService_Click_1);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(6, 18);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(1227, 44);
            this.label19.TabIndex = 0;
            this.label19.Text = resources.GetString("label19.Text");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(1414, 738);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Desafio Rede Service - Thiago Ribeiro";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDataJson)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBancos)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox numeroInformado;
        private System.Windows.Forms.Button adicionarNumero;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox txtCEP;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtBairro;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCidade;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtRua;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnCarregarGrid;
        private System.Windows.Forms.Button btnCriarArquivoDataJson;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button exibirBancos;
        private System.Windows.Forms.TextBox txtComplemento2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtCepResultado;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtUnidadesPostagem;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtEstado;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridViewBancos;
        private System.Windows.Forms.DataGridView gridDataJson;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button baixarImagemRedeService;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox numerosCrescentes;
        private System.Windows.Forms.Button btnAbrirArquivoNumeros;
        private System.Windows.Forms.Button btnCriarArquivoNumeros;
    }
}

